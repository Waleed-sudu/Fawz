# Fawz Paints & Decor — Pro Version

A fully polished single-page website for Fawz Paints & Decor, built around the new logo and hero visual.

## Files
- `fawz-paints-decor-pro.html` — main site file
- `assets/fawz-logo.jpg` — logo image
- `assets/fawz-hero.jpg` — hero identity image

## How to use
1. Create a new GitHub repository (e.g., `fawz-website`).
2. Upload all files from this folder to the repo.
3. In repository settings, enable GitHub Pages and select the main branch.
4. After deployment, your site will be available at `https://<username>.github.io/<repo-name>/fawz-paints-decor-pro.html`.

The page is:
- RTL Arabic with light English touch for brand feel.
- Responsive (mobile & desktop) with light/dark themes.
- Ready to extend into product pages or integrate with your Flutter app.
